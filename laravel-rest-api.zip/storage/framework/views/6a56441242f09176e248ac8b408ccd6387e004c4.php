<?php echo e($body); ?>

<?php /**PATH D:\loyihalar\deetru-backend\resources\views/email-template.blade.php ENDPATH**/ ?>